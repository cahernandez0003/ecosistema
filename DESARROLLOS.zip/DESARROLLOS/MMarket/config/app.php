<?php 



// Variables (Rutas Relativas/Absolutas)

$url_site   = 'http://192.168.1.5:8080/MMarket/';
$url_public = $url_site.'public/';
$url_css    = $url_public.'css/';
$url_js     = $url_public.'js/';
$url_imgs   = $url_public.'imgs/';

// Configuración BD SQL Server
$hostSqlServer = 'SERVIDOR\SAGE200';
$userSqlServer = 'consultasMM';
$passSqlServer = 'Sage2009+';
$nmdbSqlServer = 'MMARKET';


// Configuración BD MySQL
// $hostMySQL = 'localhost';
// $userMySQL = 'root';
// $passMySQL = '';
// $nmdbMySQL = 'cuvinor22';